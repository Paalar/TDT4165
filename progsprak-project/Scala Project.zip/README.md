# progsprak-project
_Authors:_ Ole Anders Stokker, Henrik Liodden, & Pål-Edward Larsen

Subtasks are divided by comments,
```
//a
 ...code
//b
 ...code
```
Each subtask contains examples to show that the subtasks are properly implemented. They are displayed by the ```print``` statements.

## Task 3 / Scala project
Running the task takes approximately 50 seconds
